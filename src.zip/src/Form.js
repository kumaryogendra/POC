import React, {Component} from 'react';

class Form extends Component {
    constructor(props) {
        super(props);
        
        this.initialState = {
            name: '',
            job: ''
        };

        this.state = this.initialState;
    }

    handleChange = event => {
        const { name, value } = event.target;

        this.setState({
            [name] : value
        });
    }

    onFormSubmit = (event) => {
        event.preventDefault();
        
        this.props.handleSubmit(this.state);
        this.setState(this.initialState);
    }

    render() {
        const { Firstname, LastName } = this.state; 

        return (
            <form onSubmit={this.onFormSubmit}>
                <label for="FirstName">FirstName</label>
                <input 
                    type="text" 
                    name="Firstname" 
                    id="Firstname"
                    value={Firstname} 
                    onChange={this.handleChange} />
                <label for="LastName">LastName</label>
                <input 
                    type="text" 
                    name="LastName" 
                    id="LastName"
                    value={LastName} 
                    onChange={this.handleChange} />
               
            </form>
        );
    }
}

export default Form;
