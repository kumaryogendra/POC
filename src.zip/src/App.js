import React, { Component } from 'react';
import Table from './Table';
import Form from './Form';
import Api from './Api';

class App extends Component {
    state = {
        characters: []
    };


  
//Control rendering 

    removeCharacter = index => {
        const { characters } = this.state;
    
        this.setState({
            characters: characters.filter((character, i) => { 
                return i !== index;
            })
        });
    }

    handleSubmit = character => {
        this.setState({characters: [...this.state.characters, character]});
    }

    render() {
        const { characters } = this.state;
        
        return (
            <div className="container">
                 <h1><Api/></h1>
                
                <p>Team Name - SWIE </p>
                <p>Enter you First Name and Last Name </p>
                <Table
                    characterData={characters}
                    removeCharacter={this.removeCharacter}
                />
                <div className='serviceitem'> 
                
                </div>
                <Form handleSubmit={this.handleSubmit} />
            
            </div>
        );
    }
}

export default App;